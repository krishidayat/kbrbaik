import React, { useEffect, useState } from "react";
import { Activity, Radio, Cpu, Sparkles, Key, AlertCircle } from "lucide-react";

export default function Header() {
  const [apiKeyStatus, setApiKeyStatus] = useState<"checking" | "active" | "simulated">("checking");
  const [vpsUptime, setVpsUptime] = useState("0h 0m 0s");

  useEffect(() => {
    // Check if the server has a real API key or is running simulated
    const checkApiKey = async () => {
      try {
        const response = await fetch("/api/gemini/chat", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ messages: [{ role: "user", content: "ping" }] })
        });
        const data = await response.json();
        if (data.fallback) {
          setApiKeyStatus("simulated");
        } else {
          setApiKeyStatus("active");
        }
      } catch (err) {
        setApiKeyStatus("simulated");
      }
    };
    checkApiKey();

    // Subtle simulator clock
    const start = Date.now();
    const timer = setInterval(() => {
      const diff = Date.now() - start;
      const secs = Math.floor((diff / 1000) % 60);
      const mins = Math.floor((diff / (1000 * 60)) % 60);
      const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
      setVpsUptime(`${hours}h ${mins}m ${secs}s`);
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  return (
    <header className="bg-slate-900 border-b border-slate-800 text-white py-5 px-6 sticky top-0 z-50 shadow-md" id="app-header">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        {/* Branding */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-teal-500 flex items-center justify-center shadow-lg shadow-teal-500/20 glow-teal">
            <Radio className="w-6 h-6 text-slate-900 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-display font-extrabold text-2xl tracking-tight bg-gradient-to-r from-teal-400 to-cyan-300 bg-clip-text text-transparent">
                KbrBaik
              </span>
              <span className="text-[10px] font-mono uppercase bg-slate-800 text-teal-300 px-2 py-0.5 rounded border border-slate-700 font-semibold tracking-wider">
                System Hub
              </span>
            </div>
            <p className="text-xs text-slate-400 font-sans tracking-wide">
              Pusat Kendali Kolaborasi & Otomatisasi AI Kristen - Jabar Jemaat
            </p>
          </div>
        </div>

        {/* Live System Metas & Gemini Status */}
        <div className="flex flex-wrap items-center gap-3 md:gap-4 text-xs font-mono">
          {/* VPS Health Status */}
          <div className="bg-slate-950 px-3 py-2 rounded-lg border border-slate-800 flex items-center gap-2" title="Status server otonom KbrBaik">
            <Cpu className="w-3.5 h-3.5 text-teal-400" />
            <span className="text-slate-400">VPS Engine:</span>
            <span className="text-emerald-400 font-semibold flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping"></span>
              99.9%
            </span>
            <span className="text-slate-600">|</span>
            <span className="text-slate-400">UP:</span>
            <span className="text-slate-300">{vpsUptime}</span>
          </div>

          {/* Icecast Node */}
          <div className="bg-slate-950 px-3 py-2 rounded-lg border border-slate-800 flex items-center gap-2" title="Streaming Radio Broadcast Icecast Server">
            <Activity className="w-3.5 h-3.5 text-indigo-400 animate-pulse" />
            <span className="text-slate-400">Icecast:</span>
            <span className="text-indigo-300 font-semibold">Live (Port 3000)</span>
          </div>

          {/* AI Active Indicator */}
          {apiKeyStatus === "checking" ? (
            <div className="bg-slate-950 px-3 py-2 rounded-lg border border-slate-800 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-yellow-400 animate-bounce"></span>
              <span className="text-slate-400">Mendeteksi AI...</span>
            </div>
          ) : apiKeyStatus === "active" ? (
            <div className="bg-emerald-950/40 text-emerald-300 border border-emerald-800/60 px-3 py-2 rounded-lg flex items-center gap-1.5 shadow-sm glow-teal" title="Model AI Gemini Berfungsi Penuh!">
              <Sparkles className="w-3.5 h-3.5 text-teal-400" />
              <span className="font-semibold text-[11px] uppercase tracking-wide">Gemini AI Active</span>
            </div>
          ) : (
            <div className="bg-amber-950/40 text-amber-300 border border-amber-900/60 px-3 py-2 rounded-lg flex items-center gap-1.5" title="Menggunakan respons simulasi cerdas secara offline. Tambahkan GEMINI_API_KEY Anda di Settings > Secrets untuk mengaktifkan AI asli!">
              <Key className="w-3.5 h-3.5 text-amber-400" />
              <span className="font-semibold text-[11px] uppercase tracking-wide">Simulation Mode</span>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
