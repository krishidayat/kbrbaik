import React, { useState } from "react";
import { INPUT_TEMPLATES, FLOW_STEPS } from "../data";
import { Play, Sparkles, Send, FileText, Check, Volume2, Globe, Database, HelpCircle, RefreshCw, Layers } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

export default function FlowSimulator() {
  const [selectedTemplate, setSelectedTemplate] = useState(INPUT_TEMPLATES[0]);
  const [customTitle, setCustomTitle] = useState("");
  const [customSource, setCustomSource] = useState("");
  const [customContent, setCustomContent] = useState("");
  const [isCustomMode, setIsCustomMode] = useState(false);

  // Simulation run state
  const [isRunning, setIsRunning] = useState(false);
  const [activeStep, setActiveStep] = useState<number | null>(null);
  const [progressMsg, setProgressMsg] = useState("");
  
  // Results state
  const [results, setResults] = useState<{ wiki: string; popular: string; isFallback: boolean } | null>(null);
  const [activeTab, setActiveTab] = useState<"wiki" | "popular">("popular");

  const currentTitle = isCustomMode ? customTitle : selectedTemplate.title;
  const currentSource = isCustomMode ? customSource : selectedTemplate.source;
  const currentContent = isCustomMode ? customContent : selectedTemplate.content;

  const handleRunSimulation = async () => {
    if (!currentContent.trim()) {
      alert("Maaf, teks konten mentah tidak boleh kosong.");
      return;
    }

    setIsRunning(true);
    setResults(null);
    setActiveStep(1);
    setProgressMsg("Menyiarkan audio mentah secara live via Icecast server streaming...");

    // Step 1: Broadcaster
    await new Promise((resolve) => setTimeout(resolve, 1500));
    
    // Step 2 & 3: OpenCode Detection & Whipser Transcript
    setActiveStep(2);
    setProgressMsg("OpenCode mendeteksi siaran baru. Mengarahkan audio master menuju API Whisper...");
    await new Promise((resolve) => setTimeout(resolve, 1500));
    
    setActiveStep(3);
    setProgressMsg("Whisper memicu transkrip lisan menjadi teks mentah utuh...");
    await new Promise((resolve) => setTimeout(resolve, 1500));

    // Step 4: Hermes Brain Sifting
    setActiveStep(4);
    setProgressMsg("Hermes Agent menyaring obrolan basa-basi dan merumuskan ulang teologi...");
    
    try {
      const response = await fetch("/api/gemini/process", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: currentTitle,
          source: currentSource,
          content: currentContent,
        }),
      });
      const data = await response.json();

      // Step 5: Strapi Publication Webhooks
      setActiveStep(5);
      setProgressMsg("Strapi CMS v5 berhasil menyimpan entitas data baru dan menerbitkan ke situs web terkait.");
      await new Promise((resolve) => setTimeout(resolve, 1200));

      if (data.success) {
        setResults({
          wiki: data.wikiArticle,
          popular: data.populerArticle,
          isFallback: !!data.fallback,
        });
      } else {
        throw new Error(data.error || "Gagal memperoleh draf dari Hermes.");
      }
    } catch (err: any) {
      console.error(err);
      setProgressMsg("Gagal memproses otomatisasi AI. Berpindah ke pemulihan luring...");
      // Graceful fallback to simulate offline system sandbox
      setResults({
        wiki: `### [ARSIP WIKIAI] ${currentTitle}
**Kategori:** Teologi & Pembinaan Jemaat Jabar
**Sumber:** ${currentSource}
**Status:** Luring / Simulasi Offline

#### 1. Ringkasan Teologis Formal
Dokumen ini merekam penelaahan mendasar tentang pentingnya tema "${currentTitle}" yang berpusat pada penatalayanan pemuda di lingkungan PGIW Jawa Barat. Esensi rohani dihadirkan untuk menyikapi problematika zaman secara solutif.

#### 2. Tuntunan Sinode Resmi
*   **Kolaborasi Pelayanan:** Mengembangkan sinergi antar gereja anggota demi menyapa generasi muda.
*   **Kearifan Komunikasi:** Menggunakan setiap platform media penyiaran sebagai sarana pewartaan yang inklusif dan mendidik.
`,
        popular: `### [RENUNGAN KBRBAIK] ${currentTitle}
**Host/Podcaster:** ${currentSource}
**Vibe:** Inspiratif & Santai

Halo KbrBaikers! Senang sekali rasanya bisa berbagi insight asyik tentang topik harian kita kali ini: "${currentTitle}". 

#### 💡 Refleksi Singkat
Yuk, jangan biarkan kebisingan digital mengaburkan damai sejahtera di hati kita. Tetaplah menjadi pembawa kabar baik yang aktif bersaksi, kreatif melayani, dan bersaudara dengan tulus! 

**#KbrBaikLive #PemudaGereja #JabarEkumenis** 📡✨
`,
        isFallback: true,
      });
    } finally {
      setIsRunning(false);
      setActiveStep(null);
    }
  };

  return (
    <div className="bg-white rounded-3xl border border-slate-200/80 shadow-md p-6 md:p-8 space-y-8" id="simulation-component">
      {/* Simulation Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 pb-5">
        <div>
          <h2 className="text-xl md:text-2xl font-display font-extrabold text-slate-900 flex items-center gap-2">
            <span className="p-1 px-2.5 rounded-lg bg-teal-500 text-slate-900 text-sm font-mono font-bold">
              01
            </span>
            Hermes AI Sandbox
          </h2>
          <p className="text-sm text-slate-500 mt-1">
            Uji aliran data secara langsung. Saksikan bagaimana file khotbah / podcast diolah Hermes Agent menjadi teks terstruktur.
          </p>
        </div>
        
        {/* Input Toggle Preset / Custom */}
        <div className="flex bg-slate-100 p-1.5 rounded-xl border border-slate-200/50 self-start md:self-auto text-xs font-medium">
          <button
            onClick={() => setIsCustomMode(false)}
            className={`px-3 py-1.5 rounded-lg transition-all ${!isCustomMode ? "bg-white text-slate-900 shadow-sm" : "text-slate-500 hover:text-slate-900"}`}
          >
            Gunakan Preset Komunitas
          </button>
          <button
            onClick={() => setIsCustomMode(true)}
            className={`px-3 py-1.5 rounded-lg transition-all ${isCustomMode ? "bg-white text-slate-900 shadow-sm" : "text-slate-500 hover:text-slate-900"}`}
          >
            Tulis Teks Custom
          </button>
        </div>
      </div>

      {/* Main Grid: Input Source on Left, Step Visualizer & Output on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Side: Input Workspace (5 columns) */}
        <div className="lg:col-span-5 space-y-5">
          <div className="bg-slate-50 p-5 rounded-2xl border border-slate-200/50 space-y-4">
            <h3 className="font-display font-bold text-slate-900 text-sm flex items-center gap-2">
              <FileText className="w-4 h-4 text-teal-600" />
              Ruang Input Master Konten
            </h3>

            {!isCustomMode ? (
              <div className="space-y-3">
                <label className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider block">
                  PILIH CONTENT TEMPLATE PRESET:
                </label>
                <div className="grid grid-cols-1 gap-2">
                  {INPUT_TEMPLATES.map((tpl) => (
                    <button
                      key={tpl.id}
                      onClick={() => setSelectedTemplate(tpl)}
                      className={`p-3 rounded-xl border text-left transition-all text-xs flex flex-col gap-1 ${selectedTemplate.id === tpl.id ? "bg-white border-teal-500 text-slate-900 shadow-xs ring-2 ring-teal-500/10" : "bg-slate-100/50 border-transparent hover:bg-slate-100 text-slate-600"}`}
                    >
                      <span className="font-semibold font-display truncate text-slate-900">
                        {tpl.title}
                      </span>
                      <span className="text-[10px] font-mono text-slate-400">
                        {tpl.source}
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              <div className="space-y-3">
                <div>
                  <label className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider block mb-1">
                    Judul Konten Pelayanan
                  </label>
                  <input
                    type="text"
                    value={customTitle}
                    onChange={(e) => setCustomTitle(e.target.value)}
                    placeholder="Contoh: Kasih Menembus Sekat Perbedaan"
                    className="w-full text-xs font-sans p-3 bg-white border border-slate-200/80 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider block mb-1">
                    Asal / Sumber Saluran
                  </label>
                  <input
                    type="text"
                    value={customSource}
                    onChange={(e) => setCustomSource(e.target.value)}
                    placeholder="Contoh: Radio Pemuda Jabar live / Spotify Feed"
                    className="w-full text-xs font-sans p-3 bg-white border border-slate-200/80 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500"
                  />
                </div>
              </div>
            )}

            {/* Current Draft Meta display */}
            <div className="p-3 bg-white rounded-xl border border-slate-200/60 space-y-1.5 shadow-2xs">
              <span className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-widest block">
                INFO TRANSKRIP MASTER:
              </span>
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-slate-800 truncate" style={{ maxWidth: "240px" }}>
                  {currentTitle}
                </span>
                <span className="text-[10px] font-mono bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded truncate" style={{ maxWidth: "120px" }}>
                  {currentSource}
                </span>
              </div>
            </div>

            {/* Text draft preview container (editable always to tweak) */}
            <div>
              <label className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider block mb-1">
                Toleransi Draf Percakapan Kasar / Transkrip Whisper (Editable)
              </label>
              <textarea
                value={isCustomMode ? customContent : currentContent}
                onChange={(e) => {
                  if (isCustomMode) {
                    setCustomContent(e.target.value);
                  } else {
                    // Temporarily clone template updates as custom
                    setIsCustomMode(true);
                    setCustomTitle(selectedTemplate.title);
                    setCustomSource(selectedTemplate.source);
                    setCustomContent(e.target.value);
                  }
                }}
                rows={7}
                placeholder="Tulis draf kasar teologis, hasil transkripsi audio, atau notulensi pelayanan di sini..."
                className="w-full text-xs font-sans p-4 bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500 leading-relaxed text-slate-700"
              />
            </div>

            {/* Trigger Button */}
            <button
              onClick={handleRunSimulation}
              disabled={isRunning}
              className={`w-full py-3 px-4 rounded-xl font-display font-semibold text-sm transition-all shadow-md flex items-center justify-center gap-2 ${isRunning ? "bg-slate-200 text-slate-400 cursor-not-allowed" : "bg-slate-900 hover:bg-slate-800 text-white hover:shadow-lg"}`}
            >
              {isRunning ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin text-teal-500" />
                  Mengoperasikan Pipeline AI...
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 text-teal-400 fill-teal-400" />
                  Jalankan Aliran AI Hermes
                </>
              )}
            </button>
          </div>
        </div>

        {/* Right Side: Step Progress & Output Screen (7 columns) */}
        <div className="lg:col-span-7 flex flex-col justify-between space-y-6">
          
          {/* Step flow loading overlay or pipeline visualizer */}
          <div className="bg-slate-50 p-5 rounded-2xl border border-slate-200/50 flex-1 flex flex-col justify-between">
            <div>
              <h3 className="font-display font-bold text-slate-900 text-sm flex items-center gap-2 mb-4">
                <Layers className="w-4 h-4 text-indigo-600" />
                Siklus Kolaborasi Aktif (Automated Pipeline Trace)
              </h3>

              {/* Steps Vertical Visualizer */}
              <div className="space-y-3.5 relative">
                {/* Connecting track line */}
                <span className="absolute left-[15px] top-6 bottom-6 w-0.5 bg-slate-200"></span>

                {FLOW_STEPS.map((step) => {
                  const isActive = activeStep === step.step;
                  const isDone = activeStep !== null && activeStep > step.step;
                  
                  let circleStyle = "border-slate-300 text-slate-400 bg-white";
                  let itemStyle = "opacity-50 grayscale";

                  if (isActive) {
                    circleStyle = "bg-teal-500 border-teal-500 text-slate-900 scale-110 shadow-lg shadow-teal-500/25";
                    itemStyle = "opacity-100 border-teal-200 bg-white shadow-xs md:scale-[1.01]";
                  } else if (isDone) {
                    circleStyle = "bg-slate-900 border-slate-900 text-emerald-400";
                    itemStyle = "opacity-80 border-slate-200";
                  }

                  return (
                    <div
                      key={step.step}
                      className={`flex gap-4 p-3 rounded-xl border border-transparent transition-all duration-300 ${itemStyle}`}
                    >
                      {/* Circle Number */}
                      <div className={`w-8 h-8 rounded-full border-2 flex items-center justify-center font-mono text-xs font-bold shrink-0 transition-all ${circleStyle}`}>
                        {isDone ? <Check className="w-4 h-4 stroke-[3px]" /> : step.step}
                      </div>

                      {/* Text */}
                      <div className="space-y-0.5">
                        <h4 className="text-xs font-display font-bold text-slate-900">
                          {step.title}
                        </h4>
                        <p className="text-[11px] text-slate-500 leading-normal">
                          {isActive ? step.outcome : step.description}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Live trace activity logs block */}
            {activeStep !== null && (
              <div className="mt-5 p-3.5 bg-slate-900 rounded-xl border border-slate-800 text-slate-300 font-mono text-[11px] flex items-center gap-2.5 animate-pulse">
                <RefreshCw className="w-3.5 h-3.5 animate-spin text-teal-400 shrink-0" />
                <span className="text-slate-200">{progressMsg}</span>
              </div>
            )}
          </div>

          {/* Side-by-Side twin processed publication workspace */}
          {results && (
            <motion.div
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-slate-900 rounded-2xl overflow-hidden shadow-lg border border-slate-800"
              id="pipeline-results-preview"
            >
              {/* Tabs selectors */}
              <div className="bg-slate-950 p-1 flex border-b border-slate-800">
                <button
                  onClick={() => setActiveTab("popular")}
                  className={`flex-1 py-3 text-xs font-display font-bold rounded-xl transition-all flex items-center justify-center gap-2 ${activeTab === "popular" ? "bg-slate-900 text-teal-400 border border-slate-800 shadow-xs" : "text-slate-400 hover:text-slate-200"}`}
                >
                  <Volume2 className="w-4 h-4" />
                  kbrbaik.live (Populer / Muda)
                </button>
                <button
                  onClick={() => setActiveTab("wiki")}
                  className={`flex-1 py-3 text-xs font-display font-bold rounded-xl transition-all flex items-center justify-center gap-2 ${activeTab === "wiki" ? "bg-slate-900 text-indigo-400 border border-slate-800 shadow-xs" : "text-slate-400 hover:text-slate-200"}`}
                >
                  <Globe className="w-4 h-4" />
                  wiki.pgiwjabar.org (Formal / Wiki)
                </button>
              </div>

              {/* Rendered result */}
              <div className="p-5 overflow-y-auto max-h-[360px] bg-slate-900/45 text-slate-300 space-y-3 font-sans leading-relaxed text-xs">
                {results.isFallback && (
                  <div className="bg-amber-950/40 text-amber-300 border border-amber-900/50 p-3 rounded-lg flex items-start gap-2 text-[10px] uppercase font-mono tracking-wide leading-relaxed">
                    <span className="w-1.5 h-1.5 rounded-full bg-amber-400 mt-1 animate-ping shrink-0"></span>
                    <span>TAMPILAN SIMULATIF (DRAF OFFLINE): Konfigurasikan api-key untuk memicu penulisan artikel real-time dengan hermes AI.</span>
                  </div>
                )}

                <div className="prose prose-invert prose-xs max-w-none text-slate-300 markdown-body" style={{ color: '#cbd5e1' }}>
                  {activeTab === "popular" ? (
                    <div className="p-1 whitespace-pre-line text-xs font-sans">
                      {results.popular}
                    </div>
                  ) : (
                    <div className="p-1 whitespace-pre-line text-xs font-sans">
                      {results.wiki}
                    </div>
                  )}
                </div>
              </div>

              {/* Status footer inside results tab */}
              <div className="p-3 bg-slate-950 border-t border-slate-800 text-[10px] font-mono text-slate-500 flex justify-between items-center px-4">
                <span className="flex items-center gap-1">
                  <Database className="w-3.5 h-3.5 text-indigo-400" />
                  Entity ID: {results.isFallback ? "SIM-DRAFT" : "STRAPI-V5-DOC"}
                </span>
                <span className="text-emerald-400 font-semibold uppercase">
                  ✓ TERBIT DI {activeTab === "popular" ? "kbrbaik.live" : "wiki.pgiwjabar.org"}
                </span>
              </div>
            </motion.div>
          )}

        </div>
      </div>
    </div>
  );
}
