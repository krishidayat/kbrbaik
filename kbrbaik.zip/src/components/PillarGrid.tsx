import React, { useState } from "react";
import { PILLARS } from "../data";
import { Pillar } from "../types";
import { Code, Database, Brain, Radio, ArrowRight, ShieldCheck, Terminal, Settings } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

const renderIcon = (iconName: string, className: string) => {
  switch (iconName) {
    case "Code": return <Code className={className} />;
    case "Database": return <Database className={className} />;
    case "Brain": return <Brain className={className} />;
    case "Radio": return <Radio className={className} />;
    default: return <Settings className={className} />;
  }
};

export default function PillarGrid() {
  const [selectedPillar, setSelectedPillar] = useState<Pillar | null>(PILLARS[0]);

  return (
    <div className="space-y-6" id="pillars-section">
      <div className="flex flex-col gap-1.5">
        <h2 className="text-xl md:text-2xl font-display font-bold text-slate-900 flex items-center gap-2">
          <Settings className="w-5.5 h-5.5 text-teal-600 animate-spin" style={{ animationDuration: '6s' }} />
          4 Pilar Infrastruktur KbrBaik
        </h2>
        <p className="text-sm text-slate-500 max-w-3xl">
          Sistem ini digerakkan oleh pilar kolaboratif otonom yang bekerja bersama di dalam satu sistem Virtual Private Server (VPS). Pilih pilar untuk melihat cetak biru konfigurasi servernya.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {PILLARS.map((pillar) => {
          const isSelected = selectedPillar?.id === pillar.id;
          
          let cardColorClass = "";
          let iconBg = "";
          let textColor = "";
          let hoverBorder = "";

          if (pillar.color === "teal") {
            cardColorClass = isSelected ? "border-teal-500 bg-teal-50/80 ring-2 ring-teal-500/20" : "hover:border-teal-200 hover:bg-teal-50/30";
            iconBg = "bg-teal-500 text-slate-900";
            textColor = "text-teal-900";
            hoverBorder = "border-teal-500";
          } else if (pillar.color === "indigo") {
            cardColorClass = isSelected ? "border-indigo-500 bg-indigo-50/80 ring-2 ring-indigo-500/20" : "hover:border-indigo-200 hover:bg-indigo-50/30";
            iconBg = "bg-indigo-600 text-white";
            textColor = "text-indigo-900";
            hoverBorder = "border-indigo-500";
          } else if (pillar.color === "cyan") {
            cardColorClass = isSelected ? "border-cyan-500 bg-cyan-50/80 ring-2 ring-cyan-500/20" : "hover:border-cyan-200 hover:bg-cyan-50/30";
            iconBg = "bg-cyan-500 text-slate-900";
            textColor = "text-cyan-900";
            hoverBorder = "border-cyan-500";
          } else {
            cardColorClass = isSelected ? "border-purple-500 bg-purple-50/80 ring-2 ring-purple-500/20" : "hover:border-purple-200 hover:bg-purple-50/30";
            iconBg = "bg-purple-600 text-white";
            textColor = "text-purple-900";
            hoverBorder = "border-purple-500";
          }

          return (
            <div
              key={pillar.id}
              onClick={() => setSelectedPillar(pillar)}
              className={`p-5 rounded-2xl border bg-white transition-all cursor-pointer duration-300 relative ${cardColorClass}`}
              id={`pillar-card-${pillar.id}`}
            >
              <div className="flex justify-between items-start mb-4">
                <div className={`w-10 h-10 rounded-xl ${iconBg} flex items-center justify-center shadow-md`}>
                  {renderIcon(pillar.icon, "w-5.5 h-5.5")}
                </div>
                <span className="text-[10px] font-mono tracking-wider uppercase font-extrabold px-2.5 py-1 bg-slate-100/50 text-slate-600 rounded-full border border-slate-200/50">
                  {pillar.badge}
                </span>
              </div>
              <h3 className="font-display font-bold text-slate-900 text-lg mb-1 flex items-center gap-1.5">
                {pillar.name}
              </h3>
              <p className="text-xs font-medium text-slate-500 mb-2">
                {pillar.role}
              </p>
              <p className="text-xs text-slate-600 line-clamp-3">
                {pillar.description}
              </p>
              {isSelected && (
                <div className="absolute bottom-3 right-3 w-1.5 h-1.5 rounded-full bg-slate-900 animate-ping"></div>
              )}
            </div>
          );
        })}
      </div>

      {/* Blueprint Deep Dive Detail */}
      <AnimatePresence mode="wait">
        {selectedPillar && (
          <motion.div
            key={selectedPillar.id}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            transition={{ duration: 0.3 }}
            className="grid grid-cols-1 lg:grid-cols-12 gap-5 bg-slate-50 p-6 md:p-8 rounded-2xl border border-slate-200/60"
            id={`pillar-detail-${selectedPillar.id}`}
          >
            {/* Description and Features (8 columns in desktop) */}
            <div className="lg:col-span-7 space-y-5">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-xs font-mono font-bold uppercase py-0.5 px-2 bg-slate-200/70 text-slate-700 rounded-md">
                    Analisis Peran Detil
                  </span>
                </div>
                <h3 className="text-xl font-display font-extrabold text-slate-900">
                  {selectedPillar.name} — {selectedPillar.role}
                </h3>
                <p className="text-sm text-slate-600 mt-2 leading-relaxed">
                  {selectedPillar.description}
                </p>
              </div>

              {/* Fungsi List */}
              <div className="space-y-2.5">
                <h4 className="text-xs font-mono font-bold text-slate-500 uppercase tracking-widest">
                  FUNGSI UTAMA DI SERVER:
                </h4>
                <div className="grid grid-cols-1 gap-2">
                  {selectedPillar.fungsi.map((item, idx) => (
                    <div key={idx} className="flex gap-2.5 bg-white p-3 rounded-xl border border-slate-200/40 shadow-xs">
                      <div className="w-5 h-5 rounded-full bg-slate-100 flex items-center justify-center shrink-0 mt-0.5 text-xs font-mono font-bold text-slate-700">
                        {idx + 1}
                      </div>
                      <p className="text-xs text-slate-700 leading-normal">{item}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Dampak / Manfaat */}
              <div className="p-4 bg-white rounded-xl border border-slate-200/60 flex items-start gap-3">
                <div className="p-1.5 rounded-lg bg-teal-50 text-teal-600 mt-0.5 shadow-2xs">
                  <ShieldCheck className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-900 mb-0.5 font-display uppercase tracking-wider">
                    Dampak Positif bagi Komunitas Pemuda
                  </h4>
                  <p className="text-xs text-slate-600 leading-normal">
                    {selectedPillar.manfaat}
                  </p>
                </div>
              </div>
            </div>

            {/* Simulated Server Console & Blueprint (5 columns in desktop) */}
            <div className="lg:col-span-5 space-y-4 flex flex-col justify-between">
              <div className="bg-slate-900 rounded-xl overflow-hidden border border-slate-800 shadow-lg flex-1">
                {/* Window control header */}
                <div className="bg-slate-950 px-4 py-3 border-b border-slate-800 flex justify-between items-center text-slate-400">
                  <div className="flex items-center gap-2">
                    <Terminal className="w-4 h-4 text-slate-400" />
                    <span className="font-mono text-[11px] font-semibold tracking-wide">
                      vps-kbrbaik:/etc/{selectedPillar.id}/config.json
                    </span>
                  </div>
                  <div className="flex gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-rose-500/80"></span>
                    <span className="w-2.5 h-2.5 rounded-full bg-amber-500/80"></span>
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500/80"></span>
                  </div>
                </div>

                {/* Console Log outputs */}
                <div className="p-4 font-mono text-[11px] text-slate-300 space-y-3 whitespace-pre-line leading-relaxed overflow-x-auto">
                  <span className="text-slate-500"># Memuat cetak biru operasi server otonom...</span>
                  <div className="space-y-2">
                    {selectedPillar.detailedBlueprint.map((log, index) => (
                      <div key={index} className="flex gap-1.5 items-start">
                        <span className="text-teal-400 font-bold shrink-0">&gt;</span>
                        <span className="text-slate-200">{log}</span>
                      </div>
                    ))}
                  </div>
                  <div className="pt-3 border-t border-slate-800 text-slate-500 flex justify-between items-center">
                    <span>Status: RUNNING</span>
                    <span className="text-emerald-400 flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping"></span>
                      Otonom Aktif
                    </span>
                  </div>
                </div>
              </div>

              {/* Guide Note */}
              <p className="text-[11px] text-slate-400 leading-relaxed font-sans italic bg-slate-100 p-3 rounded-lg border border-slate-200/50">
                💡 Seluruh pilar ini bekerja berakar pada modularitas server (VPS). Dengan otomatisasi OpenCode, semua orkestrasi API terjalin aman dan bisa diuji secara instan.
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
