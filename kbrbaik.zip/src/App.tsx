import React, { useState } from "react";
import Header from "./components/Header";
import PillarGrid from "./components/PillarGrid";
import FlowSimulator from "./components/FlowSimulator";
import WikiAIChat from "./components/WikiAIChat";
import { 
  Network, 
  ArrowRight, 
  Settings, 
  Download, 
  Copy, 
  Database, 
  Plus, 
  Check, 
  HelpCircle, 
  FileCode, 
  Info,
  Layers,
  Sparkles,
  Radio,
  BookOpen
} from "lucide-react";

// Interactive schema structure options
interface SchemaField {
  name: string;
  type: string;
  description: string;
  required: boolean;
  selected: boolean;
}

const INITIAL_FIELDS: SchemaField[] = [
  { name: "id", type: "Integer (UID Auto-Increment)", description: "Pengenal unik dokumen", required: true, selected: true },
  { name: "title", type: "String", description: "Judul khotbah / berita jemaat Jabar", required: true, selected: true },
  { name: "original_source", type: "Enumeration (Radio | Spotify | YouTube)", description: "Sumber asal siaran", required: true, selected: true },
  { name: "raw_transcript", type: "Text (Long)", description: "Naskah mentah hasil transkrip audio Whisper", required: true, selected: true },
  { name: "wiki_content_formal", type: "Rich Text (Markdown)", description: "Artikel formal dengan standarisasi bahasa PGIW", required: false, selected: true },
  { name: "youth_content_populer", type: "Rich Text (Markdown)", description: "Artikel santai bergaya pemuda kbrbaik.live", required: false, selected: true },
  { name: "bidang_PGIW", type: "Enumeration (Pemuda | Wanita | Umum)", description: "Kategori bidang gereja terkait", required: true, selected: true },
  { name: "published_at", type: "DateTime", description: "Waktu penerbitan otomatis terotomasi", required: false, selected: true },
  { name: "meta_seo_keywords", type: "String", description: "Kata kunci untuk pencarian search engine", required: false, selected: false },
  { name: "audio_assets_url", type: "String", description: "Tautan URL penyimpanan format .mp3", required: false, selected: false },
];

export default function App() {
  const [fields, setFields] = useState<SchemaField[]>(INITIAL_FIELDS);
  const [newFieldName, setNewFieldName] = useState("");
  const [newFieldType, setNewFieldType] = useState("String");
  const [copied, setCopied] = useState(false);
  const [activeTab, setActiveTab] = useState<"arch" | "sandbox" | "chat" | "database">("arch");

  // Multi-site visual flow connector target
  const [hoveredNode, setHoveredNode] = useState<string | null>(null);

  const toggleFieldSelection = (index: number) => {
    const updated = [...fields];
    // Don't toggle strictly required primary fields like id and title
    if (updated[index].required && updated[index].name === "id") return;
    updated[index].selected = !updated[index].selected;
    setFields(updated);
  };

  const addCustomField = () => {
    if (!newFieldName.trim()) return;
    const item: SchemaField = {
      name: newFieldName.toLowerCase().replace(/\s+/g, "_"),
      type: newFieldType,
      description: "Custom field ditambahkan oleh tim pengembang jemaat",
      required: false,
      selected: true
    };
    setFields([...fields, item]);
    setNewFieldName("");
  };

  const getStrapiSchemaJSON = () => {
    const active = fields.filter((f) => f.selected);
    const attributes: Record<string, any> = {};

    active.forEach((f) => {
      if (f.name === "id") return; // Internal ID
      attributes[f.name] = {
        type: f.type.toLowerCase().split(" ")[0],
        required: f.required,
        configurable: true
      };
    });

    return JSON.stringify({
      collectionName: "kbrbaik_contents",
      info: {
        singularName: "kbrbaik-content",
        pluralName: "kbrbaik-contents",
        displayName: "PGIW Jabar Contents Hub",
        description: "Postgres structured storage generated dynamically for Hermes & WikiAI Jabar"
      },
      options: {
        draftAndPublish: true
      },
      attributes
    }, null, 2);
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(getStrapiSchemaJSON());
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const downloadJSONfile = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(getStrapiSchemaJSON());
    const downloadAnchor = document.createElement("a");
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", "strapi-schema-kbrbaik.json");
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans antialiased" id="master-page">
      {/* Dynamic Header */}
      <Header />

      {/* Hero Welcome Unit */}
      <section className="bg-slate-900 text-white py-12 md:py-16 px-6 relative overflow-hidden" id="hero-banner">
        {/* Abstract background graphics */}
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_120%,rgba(20,184,166,0.15),transparent_50%)]"></div>
        <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl"></div>

        <div className="max-w-7xl mx-auto relative z-10 space-y-5">
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-mono tracking-widest bg-emerald-500 text-slate-950 px-3 py-1 rounded-full font-bold">
              SYSTEM INFOGRAPHIC & EXPLORER
            </span>
            <span className="text-[11px] font-mono tracking-widest bg-slate-800 text-slate-400 px-3 py-1 rounded-full">
              KBRBAIK v1.2
            </span>
          </div>

          <div className="max-w-4xl space-y-3">
            <h1 className="text-3xl md:text-5xl font-display font-extrabold tracking-tight leading-tight">
              Ekosistem Arsitektur & <br className="hidden md:inline" />
              Taman Bermain AI Otonom <span className="bg-gradient-to-r from-teal-400 to-cyan-300 bg-clip-text text-transparent">KbrBaik</span>
            </h1>
            <p className="text-sm md:text-base text-slate-300 leading-relaxed font-sans max-w-3xl">
              Sistem inovatif yang menyatukan infrastruktur berbasis komunitas anak muda Kristen Jawa Barat, otomatisi server OpenCode, Strapi CMS v5, dan pemrosesan transkip Hermes AI secara selaras.
            </p>
          </div>

          {/* Quick Nav Tabs */}
          <div className="pt-6 flex flex-wrap gap-2.5">
            <button
              onClick={() => setActiveTab("arch")}
              className={`px-4 py-2.5 rounded-xl text-xs font-display font-bold transition-all flex items-center gap-2 ${activeTab === "arch" ? "bg-teal-500 text-slate-950 shadow-md font-bold" : "bg-slate-800 text-slate-300 hover:bg-slate-700"}`}
            >
              <Network className="w-4 h-4" />
              1. Peta Arsitektur & 4 Pilar
            </button>
            <button
              onClick={() => setActiveTab("sandbox")}
              className={`px-4 py-2.5 rounded-xl text-xs font-display font-bold transition-all flex items-center gap-2 ${activeTab === "sandbox" ? "bg-teal-500 text-slate-950 shadow-md font-bold" : "bg-slate-800 text-slate-300 hover:bg-slate-700"}`}
            >
              <Sparkles className="w-4 h-4" />
              2. Hermes AI Sandbox (Uji Coba)
            </button>
            <button
              onClick={() => setActiveTab("chat")}
              className={`px-4 py-2.5 rounded-xl text-xs font-display font-bold transition-all flex items-center gap-2 ${activeTab === "chat" ? "bg-teal-500 text-slate-950 shadow-md" : "bg-slate-800 text-slate-300 hover:bg-slate-700"}`}
            >
              <BookOpen className="w-4 h-4" />
              3. Chatbot Konsultasi WikiAI
            </button>
            <button
              onClick={() => setActiveTab("database")}
              className={`px-4 py-2.5 rounded-xl text-xs font-display font-bold transition-all flex items-center gap-2 ${activeTab === "database" ? "bg-teal-500 text-slate-950 shadow-md" : "bg-slate-800 text-slate-300 hover:bg-slate-700"}`}
            >
              <Database className="w-4 h-4" />
              4. Strapi Database Planner
            </button>
          </div>
        </div>
      </section>

      {/* Main Content Workspace Layout */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 md:px-6 py-8 md:py-12 space-y-12">
        
        {/* Tab 1: System Architecture Map & Info */}
        {activeTab === "arch" && (
          <div className="space-y-12">
            
            {/* Visual Flow Infographics Box */}
            <div className="bg-white rounded-3xl border border-slate-200/80 p-6 md:p-8 shadow-sm space-y-6">
              <div>
                <h2 className="text-xl md:text-2xl font-display font-bold text-slate-900 flex items-center gap-2">
                  <Network className="w-5.5 h-5.5 text-indigo-600" />
                  Alir Data Kolaboratif KbrBaik
                </h2>
                <p className="text-sm text-slate-500 mt-1 max-w-3xl">
                  Bagan arsitektur sistem otonom di bawah ini memetakan bagaimana data penyiaran mengalir dari input raw komunitas hingga menjadi artikel terpublikasi di kedua domain sasaran. Hover/klik modul untuk menelaah status kerjanya.
                </p>
              </div>

              {/* The Interactive Architecture Flow Area */}
              <div className="bg-slate-950 rounded-2xl p-6 md:p-8 border border-slate-800 text-white overflow-x-auto min-w-[320px] max-w-full">
                <div className="flex flex-col lg:flex-row items-center justify-between gap-6 lg:gap-3 py-4 max-w-5xl mx-auto">
                  
                  {/* Node 1: Input Komunitas */}
                  <div 
                    onMouseEnter={() => setHoveredNode("komunitas")}
                    onMouseLeave={() => setHoveredNode(null)}
                    className={`p-4 rounded-xl border transition-all duration-300 w-56 text-center select-none cursor-help ${hoveredNode === "komunitas" ? "border-teal-400 bg-slate-900 scale-105" : "border-slate-800 bg-slate-900/60"}`}
                  >
                    <span className="text-[9px] font-mono uppercase font-bold tracking-widest text-slate-500">
                      SUMBER INPUT MENTAH
                    </span>
                    <h3 className="font-display font-extrabold text-sm text-white mt-1">
                      Komunitas Anak Muda
                    </h3>
                    <p className="text-[11px] text-slate-400 mt-1.5 leading-normal">
                      Menyiarkan khotbah, podcaster, rekaman suara, laporan sinode.
                    </p>
                  </div>

                  {/* Flow arrow 1 */}
                  <div className="lg:rotate-0 rotate-90 text-slate-500 animate-pulse py-1">
                    <ArrowRight className="w-5 h-5 text-teal-400" />
                  </div>

                  {/* Node 2: OpenCode VPS Engine */}
                  <div 
                    onMouseEnter={() => setHoveredNode("opencode")}
                    onMouseLeave={() => setHoveredNode(null)}
                    className={`p-4 rounded-xl border transition-all duration-300 w-56 text-center select-none cursor-help ${hoveredNode === "opencode" ? "border-teal-400 bg-slate-900 scale-105" : "border-slate-800 bg-slate-900/60"}`}
                  >
                    <span className="text-[9px] font-mono uppercase font-bold tracking-widest text-teal-400">
                      AUTOMATION ENGINE
                    </span>
                    <h3 className="font-display font-extrabold text-sm text-white mt-1">
                      OpenCode Server
                    </h3>
                    <p className="text-[11px] text-slate-400 mt-1.5 leading-normal">
                      Mendeteksi RSS, fetch YouTube API, trigger webhook otomatis.
                    </p>
                  </div>

                  {/* Flow arrow 2 */}
                  <div className="lg:rotate-0 rotate-90 text-slate-500 animate-pulse py-1">
                    <ArrowRight className="w-5 h-5 text-indigo-400" />
                  </div>

                  {/* Node 3: Strapi Content Storage */}
                  <div 
                    onMouseEnter={() => setHoveredNode("strapi")}
                    onMouseLeave={() => setHoveredNode(null)}
                    className={`p-4 rounded-xl border transition-all duration-300 w-56 text-center select-none cursor-help ${hoveredNode === "strapi" ? "border-indigo-400 bg-slate-900 scale-105" : "border-slate-800 bg-slate-900/60"}`}
                  >
                    <span className="text-[9px] font-mono uppercase font-bold tracking-widest text-indigo-400">
                      SINGLE SOURCE OF TRUTH
                    </span>
                    <h3 className="font-display font-extrabold text-sm text-white mt-1">
                      Strapi CMS v5 (Postgres)
                    </h3>
                    <p className="text-[11px] text-slate-400 mt-1.5 leading-normal">
                      Tempat penyimpanan pusat aset digital dan setelan otorisasi RBAC.
                    </p>
                  </div>

                  {/* Flow arrow 3 */}
                  <div className="lg:rotate-0 rotate-90 text-slate-500 animate-pulse py-1">
                    <ArrowRight className="w-5 h-5 text-cyan-400" />
                  </div>

                  {/* Node 4: Hermes Agent */}
                  <div 
                    onMouseEnter={() => setHoveredNode("hermes")}
                    onMouseLeave={() => setHoveredNode(null)}
                    className={`p-4 rounded-xl border transition-all duration-300 w-56 text-center select-none cursor-help ${hoveredNode === "hermes" ? "border-cyan-400 bg-slate-900 scale-105" : "border-slate-800 bg-slate-900/60"}`}
                  >
                    <span className="text-[9px] font-mono uppercase font-bold tracking-widest text-cyan-400">
                      THE AI BRAIN (WHISPER)
                    </span>
                    <h3 className="font-display font-extrabold text-sm text-white mt-1">
                      Hermes Agent
                    </h3>
                    <p className="text-[11px] text-slate-400 mt-1.5 leading-normal">
                      Mengolah transkrip, memilah teologi, menyusun draf rilis media.
                    </p>
                  </div>

                </div>

                {/* Grid layout dual final targets (Goal 1 & Goal 2) */}
                <div className="mt-8 pt-6 border-t border-slate-900 max-w-4xl mx-auto">
                  <span className="text-[9px] font-mono text-slate-500 uppercase font-bold tracking-widest block text-center mb-4">
                    STRATEGI LUARAN GANDA AUTOMATIS (OUTPUT ENTRANCING TARGETS)
                  </span>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    
                    {/* Target A */}
                    <div 
                      onMouseEnter={() => setHoveredNode("wiki-target")}
                      onMouseLeave={() => setHoveredNode(null)}
                      className={`p-4 rounded-xl border transition-all duration-300 bg-indigo-950/20 ${hoveredNode === "wiki-target" ? "border-indigo-500" : "border-indigo-950/80"}`}
                    >
                      <span className="text-[9px] font-mono uppercase font-bold bg-indigo-900/60 text-indigo-300 px-2.5 py-0.5 rounded-full inline-block">
                        GOAL 1: WIKIAI PGIW JABAR
                      </span>
                      <h4 className="font-display font-bold text-sm text-indigo-200 mt-2">
                        wiki.pgiwjabar.org
                      </h4>
                      <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">
                        Arsip dokumen resmi sinode kearsipan multi-bidang, panduan liturgi Kristen draf formal, dan basis pengetahuan Chatbot AI Konsultasi.
                      </p>
                    </div>

                    {/* Target B */}
                    <div 
                      onMouseEnter={() => setHoveredNode("podcast-target")}
                      onMouseLeave={() => setHoveredNode(null)}
                      className={`p-4 rounded-xl border transition-all duration-300 bg-teal-950/20 ${hoveredNode === "podcast-target" ? "border-teal-500" : "border-slate-900"}`}
                    >
                      <span className="text-[9px] font-mono uppercase font-bold bg-teal-900/60 text-teal-300 px-2.5 py-0.5 rounded-full inline-block">
                        GOAL 2: JEJARING POJOK PODCAST
                      </span>
                      <h4 className="font-display font-bold text-sm text-teal-200 mt-2">
                        kbrbaik.live
                      </h4>
                      <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">
                        Platform radio streaming Icecast aktif, feed podcast terdistribusi Spotify/YouTube otomatis, dan renungan singkat bergaya anak muda.
                      </p>
                    </div>

                  </div>
                </div>

                {/* Hover reactive instructions bar */}
                <div className="mt-5 p-3.5 bg-slate-950 text-[11px] text-slate-400 text-center rounded-xl border border-slate-900 font-sans italic">
                  {hoveredNode === "komunitas" && "💡 Langkah 1: Anak muda melayani, membuat konten audio kasaran khotbah."}
                  {hoveredNode === "opencode" && "💡 Langkah 2: Skrip automasi memantau RSS Feed server & media API secara kontinu."}
                  {hoveredNode === "strapi" && "💡 Langkah 3: CMS Strapi v5 & PostgreSQL bertindak sebagai pelindung integritas data."}
                  {hoveredNode === "hermes" && "💡 Langkah 4: Otak AI mengonversi audio via Whisper dan memproses gaya penulisan ganda."}
                  {hoveredNode === "wiki-target" && "💡 Luaran Formal: Sesuai nalar pemecahan masalah teologi Kristen formal."}
                  {hoveredNode === "podcast-target" && "💡 Luaran Populer: Menyeru gaya sapaan hangat 'KbrBaikers' santai penuh semangat."}
                  {!hoveredNode && "Hubungkan cursor Anda pada salah satu bidang sirkulasi untuk melacak fungsional kerja."}
                </div>
              </div>
            </div>

            {/* 4 Pillars Section */}
            <PillarGrid />
          </div>
        )}

        {/* Tab 2: Hermes AI Sandbox */}
        {activeTab === "sandbox" && (
          <FlowSimulator />
        )}

        {/* Tab 3: WikiAI Jabar Consultation Chatbot */}
        {activeTab === "chat" && (
          <WikiAIChat />
        )}

        {/* Tab 4: Strapi Database Planner */}
        {activeTab === "database" && (
          <div className="bg-white rounded-3xl border border-slate-200/80 p-6 md:p-8 shadow-sm space-y-6" id="strapi-schema-planner">
            <div>
              <div className="flex items-center gap-2 mb-1.5">
                <span className="text-xs font-mono font-bold uppercase py-0.5 px-2 bg-indigo-50 text-indigo-700 rounded border border-indigo-200">
                  Guna Membantu Tim IT Komunitas Jabar
                </span>
                <span className="text-xs font-mono font-bold uppercase py-0.5 px-2 bg-teal-50 text-teal-700 rounded border border-teal-200">
                  PostgreSQL Native
                </span>
              </div>
              <h2 className="text-xl md:text-2xl font-display font-bold text-slate-900 flex items-center gap-2">
                <Database className="w-5.5 h-5.5 text-indigo-600 animate-pulse" />
                Strapi CMS v5 Schema Planner
              </h2>
              <p className="text-sm text-slate-500 max-w-3xl leading-relaxed">
                Menjawab pertimbangan Anda mengenai kesiapan struktur tabel database Strapi: berikut perancang skema otonom. Pilih bidang yang ingin disertakan di dalam entitas tunggal PGIW Jabar Anda, lalu ekspor sebagai skema JSON konfigurasian Strapi murni secara instan!
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Field Selectors */}
              <div className="space-y-4">
                <div className="flex justify-between items-center pb-2 border-b border-indigo-50">
                  <h3 className="font-display font-semibold text-sm text-slate-800">
                    Konfigurasi Atribut Model Data
                  </h3>
                  <span className="text-xs text-slate-400">
                    {fields.filter(f => f.selected).length} Atribut Aktif
                  </span>
                </div>

                <div className="grid grid-cols-1 gap-2 max-h-[380px] overflow-y-auto pr-2">
                  {fields.map((field, idx) => (
                    <div 
                      key={field.name}
                      onClick={() => toggleFieldSelection(idx)}
                      className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex justify-between items-center ${field.selected ? "bg-indigo-50/50 border-indigo-200 text-slate-900" : "bg-white border-slate-200 text-slate-500 hover:bg-slate-50"}`}
                    >
                      <div className="space-y-0.5">
                        <div className="flex items-center gap-2">
                          <code className="text-xs font-mono font-bold text-slate-900">
                            {field.name}
                          </code>
                          <span className="text-[10px] font-mono bg-indigo-100 text-indigo-700 px-1.5 py-0.2 rounded">
                            {field.type}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-500">
                          {field.description}
                        </p>
                      </div>

                      {field.selected ? (
                        <div className="w-5 h-5 rounded-full bg-indigo-600 text-white flex items-center justify-center">
                          <Check className="w-3.5 h-3.5 stroke-[3px]" />
                        </div>
                      ) : (
                        <div className="w-5 h-5 rounded-full border border-slate-300"></div>
                      )}
                    </div>
                  ))}
                </div>

                {/* Add Custom Field Form */}
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-250/50 space-y-3">
                  <h4 className="text-xs font-mono font-bold text-slate-500 uppercase tracking-wider block">
                    TAMBAH ATRIBUT CUSTOM BARU:
                  </h4>
                  <div className="flex flex-col md:flex-row gap-2">
                    <input
                      type="text"
                      placeholder="Nama atribut, cth: tanggal_musyawarah"
                      value={newFieldName}
                      onChange={(e) => setNewFieldName(e.target.value)}
                      className="flex-1 text-xs p-2.5 bg-white border border-slate-250 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500/20"
                    />
                    <select
                      value={newFieldType}
                      onChange={(e) => setNewFieldType(e.target.value)}
                      className="text-xs p-2.5 bg-white border border-slate-250 rounded-lg focus:outline-none"
                    >
                      <option value="String">String</option>
                      <option value="Rich Text (Markdown)">Markdown</option>
                      <option value="Enumeration">Enumeration</option>
                      <option value="DateTime">DateTime</option>
                      <option value="Boolean">Boolean</option>
                    </select>
                    <button
                      onClick={addCustomField}
                      className="px-4 py-2 bg-slate-900 text-white hover:bg-slate-800 rounded-lg text-xs font-semibold flex items-center justify-center gap-1 shrink-0"
                    >
                      <Plus className="w-4 h-4" />
                      Tambah
                    </button>
                  </div>
                </div>

              </div>

              {/* Strapi Export Preview (Right Column) */}
              <div className="flex flex-col justify-between space-y-4">
                <div className="bg-slate-900 rounded-xl border border-slate-800 overflow-hidden flex-1 flex flex-col">
                  {/* File title box */}
                  <div className="bg-slate-950 px-4 py-3 border-b border-slate-800 flex justify-between items-center text-slate-400">
                    <div className="flex items-center gap-2">
                      <FileCode className="w-4 h-4 text-emerald-400" />
                      <span className="font-mono text-[11px] font-semibold text-slate-300 tracking-wide">
                        api/kbrbaik-content/content-types/schema.json
                      </span>
                    </div>

                    <div className="flex gap-2">
                      <button
                        onClick={copyToClipboard}
                        className="p-1.5 hover:bg-slate-850 rounded text-slate-400 hover:text-white transition-all"
                        title="Salin ke papan klip"
                      >
                        {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                      </button>
                      <button
                        onClick={downloadJSONfile}
                        className="p-1.5 hover:bg-slate-850 rounded text-slate-400 hover:text-white transition-all"
                        title="Unduh skema JSON"
                      >
                        <Download className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* Schema Preview space */}
                  <div className="p-4 overflow-y-auto max-h-[320px] bg-slate-900/40 text-left">
                    <pre className="font-mono text-[11px] text-emerald-300 whitespace-pre leading-relaxed">
                      {getStrapiSchemaJSON()}
                    </pre>
                  </div>
                </div>

                {/* Context Advice Box */}
                <div className="p-4 bg-indigo-50 border border-indigo-150 rounded-xl flex items-start gap-3">
                  <Info className="w-5 h-5 text-indigo-700 shrink-0 mt-0.5" />
                  <div>
                    <h4 className="text-xs font-bold text-indigo-900 font-display">
                      Rekomendasi Tahap Eksekusi Selanjutnya
                    </h4>
                    <p className="text-[11px] text-indigo-700 leading-relaxed mt-0.5">
                      Iya, sangat dianjurkan! Tim sebaiknya mulai membuat struktur model tabel seperti ini langsung di Strapi CMS v5 panel admin. Format ini memisahkan isi teologis dari bungkusan bahasa populer jemaat secara otonom dalam relasi PostgreSQL terstruktur.
                    </p>
                  </div>
                </div>

              </div>
            </div>
          </div>
        )}

      </main>

      {/* Corporate footer */}
      <footer className="bg-slate-900 border-t border-slate-800 py-10 px-6 text-white" id="app-footer">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6 text-xs text-slate-400">
          <div className="flex items-center gap-3">
            <Radio className="w-5 h-5 text-teal-400 animate-pulse" />
            <div>
              <p className="font-semibold text-slate-300 font-display">KbrBaik System Hub v1.2</p>
              <p className="text-[11px]">Sinergitas Anak Muda, Otomasi AI Otonom, & Transmisi Injil Ekumenis</p>
            </div>
          </div>
          <div className="font-mono flex flex-wrap gap-4 text-[11px]">
            <span>PGIW JABAR</span>
            <span>•</span>
            <span>WIKIAI ENGINE</span>
            <span>•</span>
            <span>HERMES PERSISTENT</span>
            <span>•</span>
            <span>AST - 2026</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
